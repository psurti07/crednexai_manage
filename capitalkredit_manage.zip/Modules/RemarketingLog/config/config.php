<?php

return [
    'name' => 'RemarketingLog',
];
