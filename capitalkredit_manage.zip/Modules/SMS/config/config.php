<?php

return [
    'name' => 'SMS',
];
