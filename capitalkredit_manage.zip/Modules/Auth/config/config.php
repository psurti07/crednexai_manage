<?php

return [
    'name' => 'Auth',
];
