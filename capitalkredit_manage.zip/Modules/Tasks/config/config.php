<?php

return [
    'name' => 'Tasks',
];
