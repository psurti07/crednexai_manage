<?php

return [
    'name' => 'AdsContent',
];
