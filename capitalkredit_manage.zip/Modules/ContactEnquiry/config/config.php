<?php

return [
    'name' => 'ContactEnquiry',
];
