<?php

return [
    'name' => 'Career',
];
