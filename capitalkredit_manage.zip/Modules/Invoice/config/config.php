<?php

return [
    'name' => 'Invoice',
];
