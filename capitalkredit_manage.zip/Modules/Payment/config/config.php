<?php

return [
    'name' => 'Payment',
];
