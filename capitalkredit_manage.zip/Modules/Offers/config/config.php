<?php

return [
    'name' => 'Offers',
];
