<?php

return [
    'name' => 'SearchData',
];
