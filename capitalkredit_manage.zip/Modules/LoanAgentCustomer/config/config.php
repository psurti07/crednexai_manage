<?php

return [
    'name' => 'LoanAgentCustomer',
];
