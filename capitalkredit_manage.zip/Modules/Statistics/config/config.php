<?php

return [
    'name' => 'Statistics',
];
