<?php

return [
    'name' => 'SendOtp',
];
