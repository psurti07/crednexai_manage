<?php

return [
    'name' => 'ApplyLinks',
];
